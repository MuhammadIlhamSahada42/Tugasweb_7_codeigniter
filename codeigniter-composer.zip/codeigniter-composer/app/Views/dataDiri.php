<?php
// Menyimpan data diri dalam variabel
$nama = "Muhammad Ilham Sahada";
$alamat = "Jalan Pantura";
$tanggal_lahir = "1 Januari 2006";
$email = "sahada@example.com";
$no_telepon = "+628123456789";
$hobi = array("Membaca", "Berjalan-jalan", "Bermain Sepak Bola");
$pekerjaan = "Software Developer";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Diri</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        .foto{
            text-align: center;
        }
        .data-item {
            text-align: center;
            font-size: 16px;
            margin: 10px 0;
        }
        .data-item strong {
            color: #333;
        }
        .data-item span {
            color: #555;
        }
        .hobi {
            margin-top: 10px;
            font-style: italic;
            
        }

        .kembali{
            background-color: blue;
            color: #f4f4f9;
            padding: 5px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Data Diri</h1>

    <div class ="foto">
        <img src="#" alt="foto profil">
    </div>

    <div class="data-item">
        <strong>Nama :</strong> <span><?php echo $nama; ?></span>
    </div>

    <div class="data-item">
        <strong>Alamat :</strong> <span><?php echo $alamat; ?></span>
    </div>

    <div class="data-item">
        <strong>Tanggal Lahir :</strong> <span><?php echo $tanggal_lahir; ?></span>
    </div>

    <div class="data-item">
        <strong>Email :</strong> <span><?php echo $email; ?></span>
    </div>

    <div class="data-item">
        <strong>No Telepon :</strong> <span><?php echo $no_telepon; ?></span>
    </div>

    <div class="data-item hobi">
        <strong>Hobi :</strong> <span><?php echo implode(", ", $hobi); ?></span>
    </div>

    <div class="data-item">
        <strong>Pekerjaan :</strong> <span><?php echo $pekerjaan; ?></span>
    </div>

    <div >
        <a class="kembali" href="welcome_message">Kembali</a>
    </div>   
 
</div>

</body>
</html>
